# indicator_test_full.py
# Full port of A/D Context v20.x divergence/regime/quality logic to Python
# Usage: python indicator_test_full.py data.csv [profile]
# Requires: pip install pandas numpy

import sys
import json
import math
import pandas as pd
import numpy as np

# ----------------- helpers -----------------
def ema(series, span):
    return series.ewm(span=span, adjust=False).mean()

def atr(df, n):
    high = df['high']
    low = df['low']
    close = df['close']
    prev_close = close.shift(1)
    tr1 = high - low
    tr2 = (high - prev_close).abs()
    tr3 = (low - prev_close).abs()
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    return tr.rolling(window=n, min_periods=1).mean()

def detect_pivots(highs, lows, left, right):
    # Returns lists of pivot low indices and pivot high indices
    n = len(highs)
    pl = [False] * n
    ph = [False] * n
    for i in range(left, n - right):
        seg_high = highs[(i - left):(i + right + 1)]
        seg_low = lows[(i - left):(i + right + 1)]
        if highs[i] == seg_high.max() and (highs[i] > seg_high.drop(labels=[i]).max() if len(seg_high.drop(labels=[i]))>0 else True):
            ph[i] = True
        if lows[i] == seg_low.min() and (lows[i] < seg_low.drop(labels=[i]).min() if len(seg_low.drop(labels=[i]))>0 else True):
            pl[i] = True
    return pl, ph

# ----------------- profile helpers -----------------
def profile_params(profile, base_price_move_pct, base_ad_move_pct, base_atr_mult, base_cooldown):
    if profile == "15m":
        return base_price_move_pct * 1.4, base_ad_move_pct * 1.4, base_atr_mult * 1.0, base_cooldown
    if profile == "1h":
        return base_price_move_pct * 1.2, base_ad_move_pct * 1.2, base_atr_mult * 1.1, base_cooldown + 5
    if profile == "4h":
        return base_price_move_pct * 1.0, base_ad_move_pct * 1.0, base_atr_mult * 1.2, base_cooldown + 10
    return base_price_move_pct * 0.8, base_ad_move_pct * 0.8, base_atr_mult * 1.3, base_cooldown + 15

# ----------------- main compute -----------------
def compute_full(df, profile="1h",
                 flowMode="Chaikin AD",
                 cmfLen=20, emaLen=21, atrLen=14,
                 pivotLeftBase=12, pivotRightBase=12,
                 minPriceMovePct=0.15, minAdMovePct=0.35, minSwingAtr=0.8, cooldownBars=20,
                 regimeLookback=8, regimeMinSlopePct=0.20, regimeMinRangePct=0.25, regimeConfirmBars=4,
                 breakoutLen_base=5, cmfStrong_base=0.05, cmfWeak_base=0.02):
    df = df.copy().reset_index(drop=True)
    # convert types
    df[['open','high','low','close','volume']] = df[['open','high','low','close','volume']].astype(float)
    n = len(df)
    small = 1e-9

    # flow core
    barRange = (df['high'] - df['low']).replace(0, small)
    mfm = ((df['close'] - df['low']) - (df['high'] - df['close'])) / barRange
    mfv = mfm * df['volume']

    # WadUp (Williams AD style)
    prev_close = df['close'].shift(1).fillna(df['close'])
    wadUp = np.where(df['close'] > prev_close, df['close'] - np.minimum(prev_close, df['low']),
                     np.where(df['close'] < prev_close, df['close'] - np.maximum(prev_close, df['high']), 0.0))

    rawFlow = mfv.cumsum() if flowMode == "Chaikin AD" else pd.Series(wadUp).cumsum()
    smoothedFlow = ema(rawFlow, emaLen)
    flowSlope = smoothedFlow - smoothedFlow.shift(1)
    flowSlopePct = (smoothedFlow - smoothedFlow.shift(regimeLookback)) / smoothedFlow.shift(regimeLookback).abs().replace(0, small) * 100
    flowSlopePct = flowSlopePct.fillna(0)

    # normalizer
    flowScale = ema(rawFlow.abs(), max(5, regimeLookback))
    flowNorm = smoothedFlow / flowScale.replace(0, small)

    # CMF rolling via cum-diff
    cumMFV = mfv.cumsum()
    cumVol = df['volume'].cumsum()
    sumMFV = (cumMFV - cumMFV.shift(cmfLen)).fillna(cumMFV)
    sumVol = (cumVol - cumVol.shift(cmfLen)).fillna(cumVol)
    cmfVal = (sumMFV / sumVol).fillna(0)

    # ATR
    atrValSeries = atr(df, atrLen)
    atrVal = atrValSeries.bfill().fillna(0)

    # regime
    emaSlopePct = ((smoothedFlow - smoothedFlow.shift(regimeLookback)) / smoothedFlow.shift(regimeLookback).abs().replace(0, small) * 100).fillna(0)
    emaRangePct = (smoothedFlow.rolling(window=regimeLookback, min_periods=1).max() - smoothedFlow.rolling(window=regimeLookback, min_periods=1).min()).abs() / smoothedFlow.abs().replace(0, small) * 100
    emaRangePct = emaRangePct.fillna(0)

    bullCount = 0
    bearCount = 0
    bullRegimeArr = [False]*n
    bearRegimeArr = [False]*n

    for i in range(n):
        if i==0:
            bullCount = 0
            bearCount = 0
        else:
            bullCount = bullCount + 1 if smoothedFlow.iloc[i] > smoothedFlow.iloc[i-1] else 0
            bearCount = bearCount + 1 if smoothedFlow.iloc[i] < smoothedFlow.iloc[i-1] else 0
        bullRegime = bullCount >= regimeConfirmBars and emaSlopePct.iloc[i] > regimeMinSlopePct and emaRangePct.iloc[i] > regimeMinRangePct and (smoothedFlow.iloc[i] > smoothedFlow.iloc[max(0, i-regimeLookback)])
        bearRegime = bearCount >= regimeConfirmBars and emaSlopePct.iloc[i] < -regimeMinSlopePct and emaRangePct.iloc[i] > regimeMinRangePct and (smoothedFlow.iloc[i] < smoothedFlow.iloc[max(0, i-regimeLookback)])
        bullRegimeArr[i] = bool(bullRegime)
        bearRegimeArr[i] = bool(bearRegime)

    # adRegime string (last)
    last_idx = n-1
    if bullRegimeArr[last_idx]:
        adRegime = "bull"
    elif bearRegimeArr[last_idx]:
        adRegime = "bear"
    elif abs(emaSlopePct.iloc[last_idx]) < regimeMinSlopePct:
        adRegime = "flat"
    else:
        adRegime = "transition"

    # profile-specific thresholds
    profilePriceMovePct, profileAdMovePct, profileAtrMult, profileCooldown = profile_params(profile, minPriceMovePct, minAdMovePct, minSwingAtr, cooldownBars)
    # adaptive cmf thresholds
    cmfStrongTf = 0.04 if profile=="15m" else 0.05 if profile=="1h" else 0.06 if profile=="4h" else 0.07
    cmfWeakTf = 0.015 if profile=="15m" else 0.02 if profile=="1h" else 0.025 if profile=="4h" else 0.03
    brLen = 4 if profile=="15m" else 5 if profile=="1h" else 6 if profile=="4h" else 8

    # bias scoring (last)
    flowScoreVal = 1.0 if flowSlope.iloc[last_idx] > 0 else -1.0 if flowSlope.iloc[last_idx] < 0 else 0.0
    cmfValLast = cmfVal.iloc[last_idx]
    cmfScoreVal = 1.5 if cmfValLast > cmfStrongTf else 0.5 if cmfValLast > cmfWeakTf else -1.5 if cmfValLast < -cmfStrongTf else -0.5 if cmfValLast < -cmfWeakTf else 0.0
    regimeScoreVal = 1.0 if bullRegimeArr[last_idx] else -1.0 if bearRegimeArr[last_idx] else 0.0
    biasScore = flowScoreVal + cmfScoreVal + regimeScoreVal
    if biasScore >= 2.0:
        adBias = "bullish"
    elif biasScore <= -2.0:
        adBias = "bearish"
    else:
        adBias = "neutral"

    # confirmation (breakout)
    highest_prev = df['high'].rolling(window=brLen, min_periods=1).max().shift(1).fillna(df['high'].expanding().max())
    lowest_prev = df['low'].rolling(window=brLen, min_periods=1).min().shift(1).fillna(df['low'].expanding().min())
    bullBreak = df['close'].iloc[last_idx] >= highest_prev.iloc[last_idx]
    bearBreak = df['close'].iloc[last_idx] <= lowest_prev.iloc[last_idx]
    bullConfirmStrong = (adBias == "bullish") and (cmfValLast > cmfStrongTf) and (flowSlope.iloc[last_idx] > 0) and bullBreak
    bearConfirmStrong = (adBias == "bearish") and (cmfValLast < -cmfStrongTf) and (flowSlope.iloc[last_idx] < 0) and bearBreak
    bullConfirmWeak = (adBias == "bullish") and (cmfValLast > cmfWeakTf) and (flowSlope.iloc[last_idx] > 0)
    bearConfirmWeak = (adBias == "bearish") and (cmfValLast < -cmfWeakTf) and (flowSlope.iloc[last_idx] < 0)
    if bullConfirmStrong:
        adConfirmation = "strong_bullish"
    elif bearConfirmStrong:
        adConfirmation = "strong_bearish"
    elif bullConfirmWeak or bearConfirmWeak:
        adConfirmation = "weak"
    else:
        adConfirmation = "none"

    # ---- Replace divergence detection loop in compute_full with this patched version ----
    # Divergence detection (patched): use flowNorm and an absolute-change floor to avoid tiny-base % explosions
    pivotLeft = pivotLeftBase if profile!="15m" else max(pivotLeftBase, 10)
    pivotRight = pivotRightBase if profile!="15m" else max(pivotRightBase, 10)
    # compute pivot booleans (reuse detect_pivots)
    pl_bool, ph_bool = detect_pivots(df['high'], df['low'], pivotLeft, pivotRight)

    prevPriceLow = None
    prevFlowLow = None
    prevBullBar = None
    prevPriceHigh = None
    prevFlowHigh = None
    prevBearBar = None

    bullDiv = False
    bearDiv = False

    # parameters
    minFlowAbsFrac = 0.03  # 0.03 = conservative start; increase to 0.05..0.08 if still noisy
    # iterate indices in order of appearance
    for i in range(len(df)):
        if pl_bool[i]:
            currBar = i - pivotRight
            currPriceLow = df['low'].iloc[i]
            # use normalized flow (safer than raw cumulative)
            currFlowLow = flowNorm.iloc[i]
            if prevPriceLow is not None and prevFlowLow is not None:
                # price percent move (as before)
                priceMoveOk = abs(currPriceLow - prevPriceLow) / max(prevPriceLow, small) * 100 >= (profilePriceMovePct * 100)
                # flow percent change (based on normalized flow) + absolute-change floor
                flowPctChange = abs(currFlowLow - prevFlowLow) / max(abs(prevFlowLow), small) * 100
                minFlowAbsChange = max(abs(flowScale.iloc[i]) * minFlowAbsFrac, 1e-6)
                flowAbsChange = abs(currFlowLow - prevFlowLow)
                flowMoveOk = (flowPctChange >= (profileAdMovePct * 100)) and (flowAbsChange >= minFlowAbsChange)
                atrOk = abs(currPriceLow - prevPriceLow) >= (atrVal.iloc[i] * profileAtrMult)
                rawBull = (currPriceLow < prevPriceLow) and (currFlowLow > prevFlowLow) and priceMoveOk and flowMoveOk and atrOk
                cooldownOk = (prevBullBar is None) or (currBar - prevBullBar >= profileCooldown)
                if rawBull and cooldownOk:
                    bullDiv = True
                    prevBullBar = currBar
            prevPriceLow = currPriceLow
            prevFlowLow = currFlowLow

        if ph_bool[i]:
            currBar = i - pivotRight
            currPriceHigh = df['high'].iloc[i]
            currFlowHigh = flowNorm.iloc[i]
            if prevPriceHigh is not None and prevFlowHigh is not None:
                priceMoveOk = abs(currPriceHigh - prevPriceHigh) / max(prevPriceHigh, small) * 100 >= (profilePriceMovePct * 100)
                flowPctChange = abs(currFlowHigh - prevFlowHigh) / max(abs(prevFlowHigh), small) * 100
                minFlowAbsChange = max(abs(flowScale.iloc[i]) * minFlowAbsFrac, 1e-6)
                flowAbsChange = abs(currFlowHigh - prevFlowHigh)
                flowMoveOk = (flowPctChange >= (profileAdMovePct * 100)) and (flowAbsChange >= minFlowAbsChange)
                atrOk = abs(currPriceHigh - prevPriceHigh) >= (atrVal.iloc[i] * profileAtrMult)
                rawBear = (currPriceHigh > prevPriceHigh) and (currFlowHigh < prevFlowHigh) and priceMoveOk and flowMoveOk and atrOk
                cooldownOk = (prevBearBar is None) or (currBar - prevBearBar >= profileCooldown)
                if rawBear and cooldownOk:
                    bearDiv = True
                    prevBearBar = currBar
            prevPriceHigh = currPriceHigh
            prevFlowHigh = currFlowHigh

    adDivergence = "bullish" if bullDiv else "bearish" if bearDiv else "none"
    # ---------------------------------------------------------------------------------------

    # Build return dictionary (last state)
    out = {
        "profile": profile,
        "flow_mode": flowMode,
        "raw_flow": float(rawFlow.iloc[last_idx]) if not rawFlow.empty else 0.0,
        "smoothed_flow": float(smoothedFlow.iloc[last_idx]) if not smoothedFlow.empty else 0.0,
        "flow_slope_pct": float(flowSlopePct.iloc[last_idx]) if not flowSlopePct.empty else 0.0,
        "cmf": float(cmfVal.iloc[last_idx]) if not cmfVal.empty else 0.0,
        "ad_bias": adBias,
        "ad_confirmation": adConfirmation,
        "ad_divergence": adDivergence,
        "ad_regime": adRegime,
        "ad_quality": "medium" if (adConfirmation != "none" or adDivergence != "none") else "low",
        "ad_comment": ""
    }

    return out

# ----------------- CLI -----------------
if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python indicator_test_full.py data.csv [profile]")
        sys.exit(1)
    infile = sys.argv[1]
    profile = sys.argv[2] if len(sys.argv) > 2 else "1h"
    df = pd.read_csv(infile, parse_dates=['time'])
    res = compute_full(df, profile=profile)
    print(json.dumps(res))

# ----------------- trace helper (per-bar) - robust defaults -----------------
def compute_full_internal_trace(df, profile="1h"):
    """
    Возвращает DataFrame с per-bar snapshot'ами, вызывая compute_full на префиксах.
    Защищённая версия: подставляет разумные дефолты при ошибках и считает количество ошибок.
    """
    import sys
    df = df.copy().reset_index(drop=True)
    n = len(df)
    rows = []
    fail_count = 0

    # sensible default output (not None) so CSV has explicit "none"/"neutral"/0 values
    def default_out():
        return {
            "profile": profile,
            "flow_mode": "Chaikin",
            "raw_flow": 0.0,
            "smoothed_flow": 0.0,
            "flow_slope_pct": 0.0,
            "cmf": 0.0,
            "ad_bias": "neutral",
            "ad_confirmation": "none",
            "ad_divergence": "none",
            "ad_regime": "flat",
            "ad_quality": "low",
            "ad_comment": ""
        }

    # conservative minimal prefix length based on typical defaults
    min_required = 25

    for i in range(n):
        sub = df.iloc[:i+1].reset_index(drop=True)
        out = None

        if (i + 1) < min_required:
            # not enough bars to compute reliable indicators — use defaults
            out = default_out()
        else:
            try:
                out = compute_full(sub, profile=profile)
                if not isinstance(out, dict):
                    print(f"compute_full returned non-dict at index {i} (time={df['time'].iloc[i] if 'time' in df.columns else i})", file=sys.stderr)
                    out = None
            except Exception as e:
                fail_count += 1
                print(f"compute_full FAILED at index {i} (time={df['time'].iloc[i] if 'time' in df.columns else i}): {e}", file=sys.stderr)
                out = None

            if not isinstance(out, dict):
                out = default_out()

        row = {
            "time": df['time'].iloc[i] if 'time' in df.columns else None,
            "open": df['open'].iloc[i] if 'open' in df.columns else None,
            "high": df['high'].iloc[i] if 'high' in df.columns else None,
            "low": df['low'].iloc[i] if 'low' in df.columns else None,
            "close": df['close'].iloc[i] if 'close' in df.columns else None,
            "volume": df['volume'].iloc[i] if 'volume' in df.columns else None,
            "raw_flow": out.get("raw_flow"),
            "smoothed_flow": out.get("smoothed_flow"),
            "flow_slope_pct": out.get("flow_slope_pct"),
            "cmf": out.get("cmf"),
            "ad_bias": out.get("ad_bias"),
            "ad_confirmation": out.get("ad_confirmation"),
            "ad_divergence": out.get("ad_divergence"),
            "ad_regime": out.get("ad_regime"),
            "ad_quality": out.get("ad_quality"),
            "ad_comment": out.get("ad_comment")
        }
        rows.append(row)

    trace_df = pd.DataFrame(rows)

    if fail_count > 0:
        print(f"compute_full failed {fail_count} times while building trace (see stderr lines).", file=sys.stderr)

    return trace_df